<?php

namespace App\Http\Controllers;

use App\Models\Driver;
use App\Models\Order;
use Illuminate\Http\Request;

class DriverController extends Controller
{
    public function showDriver(Request $request)
    {
        // if ($request->has('tanggal_keberangkatan')) {

        //     $orders = Order::where('tanggal_keberangkatan', $request->tanggal_keberangkatan)->get();
        //     $list = array();
        //     foreach ($orders as $order) {
        //         array_push($list, [$order->driver_id, $order->jumlah_kursi]);
        //     }

        // $size = count($list) - 1;
        // $sums = array();
        // $filter_kursi = array();

        // for ($i = 0; $i < $size; $i++) {
        //     for ($j = 0; $j < $size - $i; $j++) {
        //         $k = $j + 1;
        //         if ($list[$k] < $list[$j]) {
        //             list($list[$j], $list[$k]) = array($list[$k], $list[$j]);
        //         }
        //         if ($list[$k] === $list[$j]) {
        //             foreach (array_keys($list[$k] + $list[$j]) as $key) {
        //                 $sums[$list[$key][0]] = @($list[$k][1] + $list[$j][1]);
        //             }
        //         }
        //     }
        // }

        //     return $orders;
        // } else {

        $driver = Driver::all();
        return $driver;
        // }
    }
}
