<?php

namespace App\Http\Controllers;

use App\Models\Checkouts;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    /**
     * Store a new user.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function show(Request $request)
    {
        if ($request->has('uid')) {

            $order = Order::where('user_id', $request->uid)->get();
        }
        return $order;
    }
    public function store(Request $request)
    {
        $orders = new Order;
        $orders->driver_id                      = $request->driver_id;
        $orders->user_id                        = Auth::id();
        $orders->dari                           = $request->dari;
        $orders->alamat_dari                    = $request->alamat_dari;
        $orders->ke                             = $request->ke;
        $orders->alamat_tujuan                  = $request->alamat_tujuan;
        $orders->tanggal_keberangkatan          = $request->tanggal_keberangkatan;
        $orders->waktu_keberangkatan            = $request->waktu_keberangkatan;
        $orders->jumlah_kursi                   = $request->jumlah_kursi;
        if ($orders->save()) {
            $checkouts = Checkouts::where('orders_id', $orders->id)->get();
            if (!$checkouts) {
                $insert = new Checkouts();
                $insert->driver_id              = $orders->driver_id;
                $insert->order_id               = $orders->id;
                $insert->tanggal_keberangkatan  = $orders->tanggal_keberangkatan;
                $insert->jumlah_kursi           = $orders->$orders->jumlah_kursi;
                $insert->save();
            }
        }

        return response()->json([
            'status' => 200,
            'message' => 'Success!',
        ]);
    }
}
