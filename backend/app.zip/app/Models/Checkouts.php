<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Checkouts extends Model
{
    use HasFactory;
    protected $table = 'tb_checkouts';
    protected $with = ['driver', 'user'];
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function order()
    {
        return $this->belongsTo(Order::class);
    }
    public function getUserAttribute()
    {
        return $this->belongsTo(User::class);
    }
    public function getOrderAttribute()
    {
        return $this->belongsTo(Order::class);
    }
}
