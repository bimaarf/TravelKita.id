<?php

namespace App\Http\Controllers;

use App\Models\Chatting;
use Illuminate\Http\Request;

class ChattingController extends Controller
{
    public function show()
    {
        $chatting = Chatting::all();
        return $chatting;
    }
    public function store(Request $request)
    {
        $chatting = new Chatting();
        $chatting->message = $request->message;
        $chatting->order_id = $request->order_id;
        $chatting->user_id  = $request->user_id;
        $chatting->driver_id = $request->driver_id;
        $chatting->save();
        return response()->json([
            'status' => 200,
            'message' => 'Success!',
        ]);
    }
}
